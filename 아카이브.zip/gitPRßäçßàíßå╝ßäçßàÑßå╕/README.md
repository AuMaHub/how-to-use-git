# GIT Pull requests 방법

## 요청하는 사람
---
1. 협업하는 깃 클론
2. 브렌치 확인
3. 브렌치 생성
4. 브렌치 체크아웃
5. 변경내용 추가
6. 변경내용 커밋
7. 브렌치 업스트림 푸시


## 승인해주는 사람
---
<<<<<<< Updated upstream
 git add .
git commit -a -m "testing first commit"
=======
   > 승인해주는 사람한테는 풀 리퀘스트가 발생할 시 이메일이 간다.

   > Ready for review를 눌러 병합 할 내용을 확인
   ![Ready for review](assets/PR_admin_1.png)

   > Merge pull request를 누른 후 컨펌하여 병합
   ![Merge pull request](assets/PR_admin_2.png)

   > Delete branch를 눌러 브렌치가 쌓이지 않도록 관리
   ![Delete branch](assets/PR_admin_3.png)
>>>>>>> Stashed changes
